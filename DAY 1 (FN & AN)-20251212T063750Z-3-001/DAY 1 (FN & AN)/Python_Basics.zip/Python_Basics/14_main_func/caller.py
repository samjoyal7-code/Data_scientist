import area

print("Inside caller.py")
print(area.calculate_triangle_area(10,30))